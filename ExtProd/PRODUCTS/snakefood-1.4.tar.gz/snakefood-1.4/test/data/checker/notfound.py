#!/usr/bin/env python
"""
"""

from __future__ import with_statement
from os.path import *
import os
import logging


class Bli(object):

    def foo(self):
        pass
    

def main():
    files = os.listdir('bin')
    a.c.b = 3

    t = Bli()

    (f, g) = 2, 3
    [h, i] = 2, 3

    map(itemgetter(0), [1, 2, 3])

if __name__ == '__main__':
    main()

    for i in range(10):
        pass

    with open('bli') as bla:
        bla.write()
        
    
