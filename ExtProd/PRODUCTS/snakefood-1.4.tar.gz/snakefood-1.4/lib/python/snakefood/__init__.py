"""
Snakefood dependency graph generator for Python source code.
"""
