from __future__ import absolute_import
import string
print string
