/*
**	Memory.h	- 
**
**
** Copyright (c) 1993  David J. Hughes
**
** Permission to use, copy, and distribute for non-commercial purposes,
** is hereby granted without fee, providing that the above copyright
** notice appear in all copies and that both the copyright notice and this
** permission notice appear in supporting documentation.
**
** This software is provided "as is" without any expressed or implied warranty.
**
** ID = "$Id: memory.h,v 1.1.1.1 1999/02/16 08:22:22 bambi Exp $"
*/


#ifndef MEMORY_SOURCE
#  ifndef _MEMORY_H
#    define _MEMORY_H
#    define malloc(s)     	Malloc(s,__FILE__,__LINE__)
#    define free(a)   		Free(a,__FILE__,__LINE__)
#    define mmap(a,l,p,fl,fd,o)	MMap(a,(size_t)l,p,fl,fd,o,__FILE__,__LINE__)
#    define munmap(a,l)		MUnmap(a,(size_t)l,__FILE__,__LINE__)
#    define strdup(s)		Strdup(s,__FILE__,__LINE__)
#  endif
#endif

