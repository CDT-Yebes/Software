
typedef struct types_s {
	char	name[25];
	int	length;
	int	(*pack)();
	int	(*unpack)();
	int	(*read)();
	int	(*write)();
	int	(*compare)();
} types_t;



	
