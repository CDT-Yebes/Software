/*
**	msqladmin.c	- 
**
**
** Copyright (c) 1993-95  David J. Hughes
** Copyright (c) 1995  Hughes Technologies Pty Ltd
**
** Permission to use, copy, and distribute for non-commercial purposes,
** is hereby granted without fee, providing that the above copyright
** notice appear in all copies and that both the copyright notice and this
** permission notice appear in supporting documentation.
**
** This software is provided "as is" without any expressed or implied warranty.
**
** ID = "$Id:"
**
*/


#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#if defined(_OS_WIN32)
#  include <winsock.h>
#endif

#include "common/portability.h"

#ifdef HAVE_SYS_UN_H
#  include <sys/un.h>
#endif


#include "common/site.h"


#include "version.h"
#include "msql_priv.h"
#define	_MSQL_SERVER_PROTO
#include "msql.h"


#include <common/site.h>
#include <common/portability.h>

int	qFlag = 0;
char	PROGNAME[] = "msqladmin";


void usage()
{
	printf("\n\nusage : msqladmin [-h host] [-f conf] [-q] <Command>\n\n");
	printf("where command =");
	printf("\t drop DatabaseName\n");
	printf("\t\t create DatabaseName\n");
	printf("\t\t copy FromDB ToDB\n");
	printf("\t\t move FromDB ToDB\n");
	printf("\t\t shutdown\n");
	printf("\t\t reload\n");
	printf("\t\t version\n");
	printf("\t\t stats\n");
	printf("\n -q\tQuiet mode.  No verification of commands.\n\n");
}


void createDB(sock,db)
	int	sock;
	char	*db;
{
	if(msqlCreateDB(sock,db) < 0)
	{
		fprintf(stderr,"\nmSQL Command failed!\nServer error = %s\n\n",
				msqlErrMsg);
		msqlClose(sock);
		exit(1);
	}
	else
	{
		printf("Database \"%s\" created.\n",db);
	}
}


void copyDB(sock,fromDB, toDB)
	int	sock;
	char	*fromDB,
		*toDB;
{
	if(msqlCopyDB(sock,fromDB, toDB) < 0)
	{
		fprintf(stderr,"\nmSQL Command failed!\nServer error = %s\n\n",
				msqlErrMsg);
		msqlClose(sock);
		exit(1);
	}
	else
	{
		printf("Database \"%s\" copied to \"%s\".\n",fromDB, toDB);
	}
}


void moveDB(sock,fromDB, toDB)
	int	sock;
	char	*fromDB,
		*toDB;
{
	if(msqlMoveDB(sock,fromDB, toDB) < 0)
	{
		fprintf(stderr,"\nmSQL Command failed!\nServer error = %s\n\n",
				msqlErrMsg);
		msqlClose(sock);
		exit(1);
	}
	else
	{
		printf("Database \"%s\" moved to \"%s\".\n",fromDB, toDB);
	}
}


void dropDB(sock,db)
	int	sock;
	char	*db;
{
	char	buf[10];


	if (!qFlag)
	{
		printf("\n\nDropping the database is potentially a very bad ");
		printf("thing to do.\nAny data stored in the database will be");
		printf(" destroyed.\n\nDo you really want to drop the ");
		printf("\"%s\" ",db);
		printf("database?  [Y/N] ");
		fflush(stdout);
		bzero(buf,10);
		fgets(buf,10,stdin);
		if ( (*buf != 'y') && (*buf != 'Y'))
		{
			printf("\n\nOK, aborting database drop!\n\n");
			msqlClose(sock);
			exit(0);
		}
	}
	if(msqlDropDB(sock,db) < 0)
	{
		fprintf(stderr,"\nmSQL Command failed!\nServer error = %s\n\n",
			msqlErrMsg);
		msqlClose(sock);
		exit(1);
	}
	else
	{
		fprintf(stderr,"Database \"%s\" dropped\n",db);
	}
}



void main(argc,argv)
	int	argc;
	char	*argv[];
{
	int	sock,
		c,
		argsLeft,
		errFlag = 0;
	char	*host = NULL,
		*confFile = NULL;
	extern	int optind;
	extern	char *optarg;

#if defined(_OS_WIN32)
	WORD	wVersion;
	WSADATA	wsaData;

#endif


	while((c=getopt(argc,argv,"f:h:q"))!= -1)
        {
                switch(c)
                {
                        case 'h':
                                if (host)
                                        errFlag++;
                                else
                                        host = optarg;
                                break;
                        case 'f':
                                if (confFile)
                                        errFlag++;
                                else
                                        confFile = optarg;
                                break;
			case 'q':
				if (qFlag)
					errFlag++;
				else
					qFlag++;
				break;
			case '?':
				errFlag++;
				break;
		}
	}

	argsLeft = argc - optind;

	if (errFlag || argsLeft == 0)
	{
		usage();
		exit(1);
	}

#if defined(_OS_WIN32)
        wVersion = MAKEWORD(1,1);
        if (WSAStartup(wVersion, &wsaData) != 0)
        {
                printf("Can't initialise WinSOCK!\n\n");
                exit(1);
        }
#endif


	msqlLoadConfigFile(confFile);

        if ((sock = msqlConnect(host)) < 0)
        {
                fprintf(stderr,"ERROR : %s\n",msqlErrMsg);
                exit(1);
        }

	if (strcmp(argv[optind],"create") == 0)
	{
		if (argsLeft != 2)
		{
			usage();
			msqlClose(sock);
			exit(1);
		}
		createDB(sock,argv[optind+1]);
		msqlClose(sock);
		exit(0);
	}
	if (strcmp(argv[optind],"drop") == 0)
	{
		if (argsLeft != 2)
		{
			usage();
			msqlClose(sock);
			exit(1);
		}
		dropDB(sock,argv[optind+1]);
		msqlClose(sock);
		exit(0);
	}
	if (strcmp(argv[optind],"copy") == 0)
	{
		if (argsLeft != 3)
		{
			usage();
			msqlClose(sock);
			exit(1);
		}
		copyDB(sock,argv[optind+1],argv[optind+2]);
		msqlClose(sock);
		exit(0);
	}
	if (strcmp(argv[optind],"move") == 0)
	{
		if (argsLeft != 3)
		{
			usage();
			msqlClose(sock);
			exit(1);
		}
		moveDB(sock,argv[optind+1],argv[optind+2]);
		msqlClose(sock);
		exit(0);
	}
	if (strcmp(argv[optind],"shutdown") == 0)
	{
		if (argsLeft != 1)
		{
			usage();
			msqlClose(sock);
			exit(1);
		}
		if(msqlShutdown(sock) < 0)
		{
			printf("\nmSQL Command failed!\nServer error = %s\n\n",
				msqlErrMsg);
			msqlClose(sock);
			exit(1);
		}
		exit(0);
	}
	if (strcmp(argv[optind],"reload") == 0)
	{
		if (argsLeft != 1)
		{
			usage();
			msqlClose(sock);
			exit(1);
		}
		if(msqlReloadAcls(sock) < 0)
		{
			printf("\nmSQL Command failed!\nServer error = %s\n\n",
				msqlErrMsg);
			msqlClose(sock);
			exit(1);
		}
		msqlClose(sock);
		exit(0);
	}
	if (strcmp(argv[optind],"version") == 0)
	{
		if (argsLeft != 1)
		{
			usage();
			msqlClose(sock);
			exit(1);
		}
		printf("\nVersion Details :-\n\n");
		printf("\tmsqladmin version \t%s\n",SERVER_VERSION);
		printf("\tmSQL server version \t%s\n", msqlGetServerInfo());
		printf("\tmSQL protocol version \t%d\n", msqlGetProtoInfo());
		printf("\tmSQL connection \t%s\n",msqlGetHostInfo());
		printf("\tTarget platform \t%s\n\n",TARGET);

		printf("Configuration Details :-\n\n");
		printf("\tDefault config file\t%s/msql.conf\n",INST_DIR);
		printf("\tTCP socket         \t%d\n", 
			msqlGetIntConf("general", "tcp_port"));
		printf("\tUNIX socket        \t%s\n", 
			(char *)msqlGetCharConf("general", "unix_port"));
		printf("\tmSQL user         \t%s\n", 
			(char *)msqlGetCharConf("general", "msql_user"));
		printf("\tAdmin user         \t%s\n", 
			(char *)msqlGetCharConf("general", "admin_user"));
		printf("\tInstall directory  \t%s\n",
			(char *)msqlGetCharConf("general", "inst_dir"));
		printf("\tPID file location  \t%s\n",
			(char *)msqlGetCharConf("general", "pid_file"));
		printf("\tMemory Sync Timer  \t%d\n",
			msqlGetIntConf("system", "msync_timer"));
		printf("\tHostname Lookup    \t%s\n",
			(msqlGetIntConf("system", "host_lookup")==0)?
			"False" : "True");
		printf("\n\n");
		msqlClose(sock);
		exit(0);
	}
	if (strcmp(argv[optind],"stats") == 0)
	{
		if (argsLeft != 1)
		{
			usage();
			msqlClose(sock);
			exit(1);
		}
		printf("\nServer Statistics\n");
		printf("-----------------\n\n");
		if (msqlGetServerStats(sock) == 0)
		{
			printf("\n\n");
			msqlClose(sock);
			exit(0);
		}
		else
		{
			printf("\nError getting server stats : %s\n\n",
				msqlErrMsg);
			exit(1);
		}
	}
	usage();
	msqlClose(sock);
	exit(1);
}
