
#include <stdio.h>

#define NUM_HASH	16

main(argc,argv)
	int	argc;
	char	*argv[];
{
	char	*cp1;
        int     hash=0;

        cp1 = argv[1];
        while(*cp1)
        {
                hash += *cp1++;
        }
        hash = hash & (NUM_HASH - 1);
	printf("Hash for '%s' is %d.\n",argv[1], hash);
}

