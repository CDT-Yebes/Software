#include <stdio.h>
#include <time.h>

main()
{
	struct	tm timeVal;

	timeVal.tm_isdst = 1;
}
