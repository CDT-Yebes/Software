#include <QuickDraw.h>

void InitToolbox()
{
	InitGraf(&qd.thePort);
}
